<template>
    <div>
        <h1>QueryString</h1>
    </div>
</template>

<script setup>

</script>

<style scoped></style>