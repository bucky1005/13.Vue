<script setup>
import { RouterLink, RouterView } from 'vue-router';

</script>

<template>
    <header>
        <h1>Router 사용하기</h1>
        <hr>
        <div class="wrapper">
            <h2>basic router</h2>
            <nav>
                <RouterLink to="/" active-class="active">Home</RouterLink>
                <RouterLink to="/pathvariable" active-class="active" replace>PathVariable</RouterLink>
                <RouterLink to="/querystring" active-class="active">QueryString</RouterLink>
            </nav>
        </div>
    </header>

    <main>
        <RouterView /> <!-- RouterView: Routerlink를 통해 매핑된 컴포넌트가 그려지는 곳 -->
    </main>
</template>

<style scoped>
nav {
    width: 100%;
    font-size: 12px;
    text-align: center;
    margin-top: 2rem;
    font-size: 30px;
}

a {
    margin-left: 10px;
}

.active {
    color: red;
}

main {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

header {
    text-align: center;
}
</style>
